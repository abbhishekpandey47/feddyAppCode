import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { ApiComponent } from './api/api.component';
import { TableComponent } from './table/table.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { FlightComponent } from './flight/flight.component';
import { FonloadComponent } from './fonload/fonload.component';
import { FoffloadComponent } from './foffload/foffload.component';
import { FreportsComponent } from './freports/freports.component';
import { PreferencesComponent } from './preferences/preferences.component';
import { CtvComponent } from './ctv/ctv.component';
import { NavbarComponent } from './navbar/navbar.component';
import { LogoutComponent } from './logout/logout.component';
import { MaincomponentComponent } from './maincomponent/maincomponent.component';
import { HelpComponent } from './help/help.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AboutComponent,
    ApiComponent,
    TableComponent,
    SidebarComponent,
    FlightComponent,
    FonloadComponent,
    FoffloadComponent,
    FreportsComponent,
    PreferencesComponent,
    CtvComponent,
    NavbarComponent,
    LogoutComponent,
    MaincomponentComponent,
    HelpComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
