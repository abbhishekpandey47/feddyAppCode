import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { ApiComponent } from './api/api.component';
import { HomeComponent } from './home/home.component';
import { FoffloadComponent } from './foffload/foffload.component';
import { FonloadComponent } from './fonload/fonload.component';
import { FreportsComponent } from './freports/freports.component';
import { PreferencesComponent } from './preferences/preferences.component';
import { LogoutComponent } from './logout/logout.component';
import { CtvComponent } from './ctv/ctv.component';
import { TableComponent } from './table/table.component';
import { HelpComponent } from './help/help.component';

const routes: Routes = [
  {path: 'home', component: HomeComponent},
  {path: 'about', component: AboutComponent},
  {path: 'api', component: ApiComponent},
  {path: 'foffload', component: FoffloadComponent},
  {path: 'fonload', component: FonloadComponent},
  {path: 'freport', component: FreportsComponent},
  {path: 'tablec', component: TableComponent},
  {path: 'preferences', component: PreferencesComponent},
  {path: 'logout', component: LogoutComponent},
  {path: 'ctv', component: CtvComponent},
  {path: 'help', component: HelpComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
