import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ctv',
  templateUrl: './ctv.component.html',
  styleUrls: ['./ctv.component.css']
})
export class CtvComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
