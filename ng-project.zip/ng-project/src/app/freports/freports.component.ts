import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-freports',
  templateUrl: './freports.component.html',
  styleUrls: ['./freports.component.css']
})
export class FreportsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
