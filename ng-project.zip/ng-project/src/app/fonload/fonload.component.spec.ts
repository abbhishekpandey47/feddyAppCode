import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FonloadComponent } from './fonload.component';

describe('FonloadComponent', () => {
  let component: FonloadComponent;
  let fixture: ComponentFixture<FonloadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FonloadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FonloadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
