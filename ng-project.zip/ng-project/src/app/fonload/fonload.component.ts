import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fonload',
  templateUrl: './fonload.component.html',
  styleUrls: ['./fonload.component.css']
})
export class FonloadComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
