// import { Injectable } from '@angular/core';
// import { Http, Response } from '@angular/http';
// import 'rxjs/add/operator/map';


// @Injectable({
//   providedIn: 'root'
// })
// export class TestingServiceService {
//   constructor (
//     private http: Http
//   ) {}

//   getUser() {
//     return this.http.get(`https://conduit.productionready.io/api/profiles/eric`)
//     .pipe((res:Response) => res.json());
//   }
// }
