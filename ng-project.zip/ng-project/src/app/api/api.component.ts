import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-api',
  templateUrl: './api.component.html',
  styleUrls: ['./api.component.css']
})
export class ApiComponent implements OnInit {

//  apiData: { age: number, name: string, delete: string }[] = [
//    { 'age': '', 'name': '', 'delete': 'X' }
//  ];

 apiData = [{'ContainerId' : '', 'Container': '', 'delete': 'X'}];
  constructor() { }

  ngOnInit() { }

    addNewForm() {
      this.apiData.push({'ContainerId' : '', 'Container': '', 'delete': 'X'});
      console.log('addNewForm');
    }
    testOrSubmit() {
      console.log('testOrSubmit');
    }
    delete (data) {
      const index = this.apiData.indexOf(data);
      console.log(index);
      this.apiData.splice(data, index);
       // console.log(da);
    }
    printData() {
      this.apiData.forEach(d => {
        console.log(d.ContainerId);
       }
       );
    }
  }
