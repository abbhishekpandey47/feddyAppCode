import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-foffload',
  templateUrl: './foffload.component.html',
  styleUrls: ['./foffload.component.css']
})
export class FoffloadComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
