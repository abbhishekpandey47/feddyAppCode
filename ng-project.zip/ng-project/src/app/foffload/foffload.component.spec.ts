import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FoffloadComponent } from './foffload.component';

describe('FoffloadComponent', () => {
  let component: FoffloadComponent;
  let fixture: ComponentFixture<FoffloadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FoffloadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FoffloadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
